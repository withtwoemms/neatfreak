require 'zlib'
require 'archive/tar/minitar'
require 'fileutils'

include Archive::Tar


STALE_AFTER = 1209600 # two weeks

def clean_up(path, *not_these)
	files = get_stale_files(path)
	tidy(files)
end

def untidy(arxv)
	Minitar.unpack(Zlib::GzipReader.new(File.open(arxv, 'rb')), './')
	FileUtils.rm_rf(arxv, secure: true)
end

private
	def get_stale_files(path, *not_these)
		Dir.chdir(path)
		files = Dir.glob('*')
		return files.select { |file| is_stale?(file) } - not_these
	end

	def is_stale?(file)
		last_used = File.stat(file).atime
		fresh_then = Time.now - STALE_AFTER
		return last_used < fresh_then
	end

	def tidy(files)
		Zlib::GzipWriter.open('./arxv.tar') do |gzip|
			out = Minitar::Output.new(gzip)
			files.each do |file|
				puts "arxv.tar << #{file}"
				Minitar.pack_file(file, out)
				FileUtils.rm_rf("#{file}", secure: true)
			end
			out.close
		end
	end
